#!/bin/bash
sudo apt-get install ros-indigo-mav-comm
sudo apt-get install ros-indigo-octomap-ros
sudo apt-get install libgoogle-glog-dev
sudo apt-get install protobuf-compiler
mkdir ros_ws
cd ros_ws
mkdir src
cd src
catkin_init_workspace
git clone https://github.com/ayushgaud/rotors_simulator.git
cd ..
catkin_make
source devel/setup.bash
echo source ~/ros_ws/devel/setup.bash >> ~/.bashrc 






