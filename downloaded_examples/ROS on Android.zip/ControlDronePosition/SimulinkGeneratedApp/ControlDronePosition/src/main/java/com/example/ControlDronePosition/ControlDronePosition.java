package com.example.ControlDronePosition;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;
import android.util.Log;
import java.util.ArrayList;
import android.content.res.Configuration;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.widget.TextView;
import android.widget.EditText;
import java.nio.charset.Charset;
import java.util.Arrays;
import android.text.InputFilter;
import android.view.KeyEvent;
import android.view.inputmethod.EditorInfo;
import java.util.Hashtable;

public class ControlDronePosition extends AppCompatActivity implements OnFragmentInteractionListener{
    private SectionsPagerAdapter mSectionsPagerAdapter;

    private ViewPager mViewPager;
     private Hashtable<Integer,EditText> editTexts = new Hashtable<Integer,EditText>();
     private Hashtable<Integer, Double> editTextValues = new Hashtable<>();
     private Hashtable<Integer, String> editTextCharValues = new Hashtable<>();

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //Uncomment the following line to specify a custom App Title
        //toolbar.setTitle("My custom Title");
        setSupportActionBar(toolbar);

        // Create a FragmentPagerAdapter that returns individual fragments
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        mViewPager.setOffscreenPageLimit(SectionsPagerAdapter.getNumTabs()-1);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);

        thisClass = this;
     }

    private ControlDronePosition thisClass;
    private final Thread BgThread = new Thread() {
    @Override
    public void run() {
            String argv[] = new String[] {"MainActivity","ControlDronePosition"};
            naMain(argv, thisClass);
        }
    };

    public void flashMessage(final String inMessage) {
        runOnUiThread(new Runnable() {
              public void run() {
                    Toast.makeText(getBaseContext(), inMessage, Toast.LENGTH_SHORT).show();
              }
        });
    }

    protected void onDestroy() {
         naOnAppStateChange(6);
         super.onDestroy();
         System.exit(0); //to kill all our threads.
    }

	@Override
    public void onFragmentCreate(String name) {

    }

    @Override
    public void onFragmentStart(String name) {
        switch (name) {
            case "Info":
               break;
            case "App":
                registerDataInputs();
                if (!BgThread.isAlive()) {
                    BgThread.start();
                }
                break;
            default:
                break;
    }
    }

    @Override
    public void onFragmentResume(String name) {
        switch (name) {
            case "App":
                break;
            default:
                break;
        }
    }

    @Override
    public void onFragmentPause(String name) {
    }
    @Override
    protected void onResume() {
         super.onResume();
         if (BgThread.isAlive())
             naOnAppStateChange(3);
    }

    @Override
    protected void onPause() {
        if (BgThread.isAlive())
            naOnAppStateChange(4);
        super.onPause();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    public void registerDataInputs() {
        // bind edit texts for data input block;
        for (int i = 1; i <= 3; i++) {
            EditText editText = (EditText) findViewById(
                    getResources().getIdentifier("DataInput" + i, "id", getPackageName()));
            if (editTextValues.containsKey(i)) {
                Log.d("registerDataInputs", "id:" + i);
                editText.setText(editTextValues.get(i).toString());
            }
            if (editTextCharValues.containsKey(i)) {
                editText.setText(editTextCharValues.get(i));
            }
            String tag = (String) editText.getTag();
            int dataType = -1;
            if (tag == null) {
                dataType = -1;
            } else {
                try {
                    dataType = Integer.parseInt(tag);
                }catch (NumberFormatException nfe) {
                    Log.e("registerDataInputs", nfe.getLocalizedMessage());
                    dataType = -1;
                }
            }
            final int id = i;
            if (dataType > 0) {
                editText.setFilters(new InputFilter[]{new InputFilterMinMax(dataType)});
                editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                    @Override
                    public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                        if ((actionId == EditorInfo.IME_ACTION_NEXT) || (actionId == EditorInfo.IME_ACTION_DONE) || (keyEvent != null && (keyEvent.getKeyCode() == KeyEvent.KEYCODE_ENTER))) {
                            try {
                                String text = textView.getText().toString();
                                double returnValue = Double.parseDouble(text);
                                editTextValues.put(id, returnValue);
                            } catch (Exception ignored) {
                                editTextValues.put(id, 0.0);
                            }
                        }
                        return false;
                    }
                });
            } else {
                editText.setOnEditorActionListener(new TextView.OnEditorActionListener() {
                    @Override
                    public boolean onEditorAction(TextView textView, int actionId, KeyEvent keyEvent) {
                        if ((actionId == EditorInfo.IME_ACTION_NEXT) || (actionId == EditorInfo.IME_ACTION_DONE) || (keyEvent != null && (keyEvent.getKeyCode() == KeyEvent.KEYCODE_ENTER))) {
                            editTextCharValues.put(id, textView.getText().toString());
                        }
                        return false;
                    }
                });
            }
            editTexts.put(i, editText);
        }
    }

    public void initDataInput(final int id, final double value, final int dataType) {
        editTextValues.put(id, value);
        if (editTexts.containsKey(id)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    String str = "";
                    if (dataType == 5 ) {
                        str = String.format("%.0f",value);
                    } else if (dataType == 7) {
                        str = String.format("%.6f",value);
                    } else if (dataType == 8) {
                        str = String.format("%.13f",value);
                    } else {
                        str = String.format("%d",(int)value);
                    }
                    editTexts.get(id).setText(str);
                }
            });
        }
    }

    public void initDataInput(final int id, byte[] value) {
        final String initValue = new String(value);
        editTextCharValues.put(id,initValue);
        if (editTextCharValues.containsKey(id)) {
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    editTexts.get(id).setText(initValue);
                }
            });
        }
    }


    public double getDataInputValue(int id) {
        return editTextValues.containsKey(id)? editTextValues.get(id) :0.0;
    }
    public byte[] getDataInputValue(int id, int maxSize) {
        String text = editTextCharValues.containsKey(id)?editTextCharValues.get(id):"";
        byte [] returnValue = Arrays.copyOf(text.getBytes(Charset.defaultCharset()),maxSize);
        return returnValue;
    }

    private native int naMain(String[] argv, ControlDronePosition pThis);
    private native void naOnAppStateChange(int state);
    static {
        System.loadLibrary("ControlDronePosition");
    }

}
