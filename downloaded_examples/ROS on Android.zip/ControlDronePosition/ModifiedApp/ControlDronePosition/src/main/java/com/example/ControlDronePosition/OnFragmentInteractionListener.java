package com.example.ControlDronePosition;


interface OnFragmentInteractionListener {
   void onFragmentCreate (String name);
   void onFragmentStart  (String name);
   void onFragmentPause  (String name);
   void onFragmentResume (String name);
}
