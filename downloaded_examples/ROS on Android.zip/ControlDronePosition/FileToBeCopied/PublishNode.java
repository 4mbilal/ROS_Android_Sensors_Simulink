/* Copyright 2018 The MathWorks, Inc. */
package com.example.ControlDronePosition;

import org.ros.message.Time;
import org.ros.namespace.GraphName;
import org.ros.node.AbstractNodeMain;
import org.ros.node.ConnectedNode;
import org.ros.node.topic.Publisher;

import geometry_msgs.PoseStamped;

public class PublishNode extends AbstractNodeMain {
    private String topic_name;
    private String message_type;
    Publisher<PoseStamped> publisher;

    public PublishNode(String topic_name, String  message_type) {
        this.topic_name = topic_name;
        this.message_type = message_type;
    }
    public PublishNode(String topic) {
        this.topic_name = topic;
    }

    public GraphName getDefaultNodeName() {
        return GraphName.of("rosindependent/publish_node");
    }

    public void onStart(ConnectedNode connectedNode) {
        publisher = connectedNode.newPublisher(this.topic_name, "geometry_msgs/PoseStamped");

    }
    public void publishData(double[] data) {
        if(publisher != null) {
            PoseStamped pose = publisher.newMessage();
            pose.getHeader().setFrameId("/map");
            pose.getHeader().setStamp(Time.fromMillis(System.currentTimeMillis()));
            pose.getPose().getPosition().setX(data[0]);
            pose.getPose().getPosition().setY(data[1]);
            pose.getPose().getPosition().setZ(data[2]);
            publisher.publish(pose);
        }
    }
}
