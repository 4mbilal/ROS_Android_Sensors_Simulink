package com.example.IMUControl;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Toast;
import android.util.Log;
import java.util.ArrayList;
import android.content.res.Configuration;
import android.support.design.widget.TabLayout;
import android.support.v4.view.ViewPager;
import android.support.v7.app.AppCompatActivity;
import android.support.v7.widget.Toolbar;
import android.content.Context;
import android.hardware.Sensor;
import android.hardware.SensorEvent;
import android.hardware.SensorEventListener;
import android.hardware.SensorManager;
import android.widget.FrameLayout;
import android.view.View;
import android.widget.ImageButton;
import android.support.v4.content.res.ResourcesCompat;
import android.os.CountDownTimer;
import android.os.Build;

public class IMUControl extends AppCompatActivity implements SensorEventListener, OnFragmentInteractionListener {
    private SectionsPagerAdapter mSectionsPagerAdapter;

    private ViewPager mViewPager;
    private ViewPager mCameraScopePager;

    private boolean isWidgetsLayoutHidden = false;
     private float[] mGyroscopeData = { 0.0f, 0.0f, 0.0f };
     private float[] mAccelerometerData = { 0.0f, 0.0f, 0.0f };
     private float[] mMagnetometerData = { 0.0f, 0.0f, 0.0f };
   private final float[] mRotationMatrix = new float[9];
private final float[] mOrientationAngles = new float[3];
     private SensorManager mSensorManager;
    private String[] scopeTitles = {"Scope"};

    private ImageButton btnZoom = null;
    private final CountDownTimer timerZoomButton = new CountDownTimer(5000, 1000) {
        @Override
        public void onTick(long l) {
            if (btnZoom!=null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                    btnZoom.setAlpha(0.5f + 0.1f*l);
                }
            }
        }

        @Override
        public void onFinish() {
            if (btnZoom != null) {
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.HONEYCOMB) {
                    btnZoom.setAlpha(0.4f);
                }
            }
        }
    };
     private void registerSensorManager() {
        mSensorManager.registerListener(this,
            mSensorManager.getDefaultSensor(Sensor.TYPE_ACCELEROMETER),
            SensorManager.SENSOR_DELAY_FASTEST);
        mSensorManager.registerListener(this,
            mSensorManager.getDefaultSensor(Sensor.TYPE_MAGNETIC_FIELD),
            SensorManager.SENSOR_DELAY_FASTEST);
        mSensorManager.registerListener(this,
            mSensorManager.getDefaultSensor(Sensor.TYPE_GYROSCOPE),
            SensorManager.SENSOR_DELAY_FASTEST);
     }

    private void registerAndSetChartSettingsOfaScope(int i) {
        FrameLayout frameLayout = (FrameLayout) findViewById(
                getResources().getIdentifier("scopeLayout" + i, "id", getPackageName()));
        if (null == frameLayout) {
            Log.e("MainActivity", "registerAndSetChartSettingsOfaScope: frameLayout is null.");
            return;
        }
        ScopeHelper.getInstance().putAChartInLayout(i, frameLayout, this);
    }

    @Override
    public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Toolbar toolbar = (Toolbar) findViewById(R.id.toolbar);
        //Uncomment the following line to specify a custom App Title
        //toolbar.setTitle("My custom Title");
        setSupportActionBar(toolbar);

        // Create a FragmentPagerAdapter that returns individual fragments
        mSectionsPagerAdapter = new SectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mViewPager = (ViewPager) findViewById(R.id.container);
        mViewPager.setAdapter(mSectionsPagerAdapter);
        mViewPager.setOffscreenPageLimit(SectionsPagerAdapter.getNumTabs()-1);

        TabLayout tabLayout = (TabLayout) findViewById(R.id.tabs);
        tabLayout.setupWithViewPager(mViewPager);

        // Initiate the SensorManager
        mSensorManager = (SensorManager) getSystemService(Context.SENSOR_SERVICE);
        thisClass = this;
     }

    private IMUControl thisClass;
    private final Thread BgThread = new Thread() {
    @Override
    public void run() {
            String argv[] = new String[] {"MainActivity","IMUControl"};
            naMain(argv, thisClass);
        }
    };

    public void flashMessage(final String inMessage) {
        runOnUiThread(new Runnable() {
              public void run() {
                    Toast.makeText(getBaseContext(), inMessage, Toast.LENGTH_SHORT).show();
              }
        });
    }

    protected void onDestroy() {
         naOnAppStateChange(6);
         super.onDestroy();
         System.exit(0); //to kill all our threads.
    }

	@Override
    public void onFragmentCreate(String name) {

    }

    @Override
    public void onFragmentStart(String name) {
        switch (name) {
            case "Info":
               break;
            case "App":
                if (mCameraScopePager == null) {
                    registerCameraScopeLayout();
                }
                if (!BgThread.isAlive()) {
                    BgThread.start();
                }
                break;
            case "dot1":
                registerAndSetChartSettingsOfaScope(1);
                break;
            default:
                break;
    }
    }

    @Override
    public void onFragmentResume(String name) {
        switch (name) {
            case "App":
                break;
            default:
                break;
        }
    }

    @Override
    public void onFragmentPause(String name) {
    }
    @Override
    protected void onResume() {
         super.onResume();
         if (BgThread.isAlive())
             naOnAppStateChange(3);
         registerSensorManager();
    }

    @Override
    protected void onPause() {
        if (BgThread.isAlive())
            naOnAppStateChange(4);
         mSensorManager.unregisterListener(this);
        super.onPause();
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
    }

    @Override
    public void onAccuracyChanged(Sensor sensor, int accuracy) {
    }

    @Override
    public void onSensorChanged(SensorEvent event) {
        float [] values = event.values;
        //Comment out if you want to log the data in logcat
        //String logMessage = String.format("%d: 0'%g'", event.sensor.getType(), values[0]);
        //Log.d("Sensor Data IN:", logMessage);
        switch(event.sensor.getType()) {
            case Sensor.TYPE_GYROSCOPE:
                mGyroscopeData[0] = values[0];
                mGyroscopeData[1] = values[1];
                mGyroscopeData[2] = values[2];
                break;
            case Sensor.TYPE_ACCELEROMETER:
                mAccelerometerData[0] = values[0];
                mAccelerometerData[1] = values[1];
                mAccelerometerData[2] = values[2];
                break;
            case Sensor.TYPE_MAGNETIC_FIELD:
                mMagnetometerData[0] = values[0];
                mMagnetometerData[1] = values[1];
                mMagnetometerData[2] = values[2];
                break;
        }
    }

    // Get SensorEvent Data throws exception if the data is null
    public float[] getGyroscopeData() {
        return mGyroscopeData;
    }

    public float[] getAccelerometerData() {
        return mAccelerometerData;
    }

    public float[] getOrientationData() {
        mSensorManager.getRotationMatrix(mRotationMatrix, null,mAccelerometerData, mMagnetometerData);
        mSensorManager.getOrientation(mRotationMatrix, mOrientationAngles);
        mOrientationAngles[0] = (float)Math.toDegrees(mOrientationAngles[0]);
        mOrientationAngles[1] = (float)Math.toDegrees(mOrientationAngles[1]);
        mOrientationAngles[2] = (float)Math.toDegrees(mOrientationAngles[2]);
        return mOrientationAngles;
    }

    public void initScope(final int scopeID, final int numInputPorts, final byte[] attribute, final float[] sampleTimes) {
        ScopeHelper scopeHelper = ScopeHelper.getInstance();
        scopeHelper.initScope(scopeID, numInputPorts, attribute, sampleTimes);
        if (!scopeHelper.checkIfScopeRegistered(scopeID)){
            Log.w("MainActivity", "Scope not registered.");
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    registerAndSetChartSettingsOfaScope(scopeID);
                }
            });
        }
        scopeHelper.setTitle(scopeID, scopeTitles[scopeID-1]);
    }

    public void cachePlotData(int scopeID, int portIdx, float[] data, int sigNumDims, int[] sigDims) {
        ScopeHelper.getInstance().cachePlotData(scopeID, portIdx, data, sigNumDims, sigDims);
    }

    public void plotData(int scopeID) {
        ScopeHelper.getInstance().plotData(scopeID);
    }
    private void registerCameraScopeLayout() {
        // Create the adapter that will return a fragment for each of the three
        // primary sections of the activity.
        CameraScopeSectionsPagerAdapter mCameraScopeAdapter = new CameraScopeSectionsPagerAdapter(getSupportFragmentManager());

        // Set up the ViewPager with the sections adapter.
        mCameraScopePager = (ViewPager) findViewById(R.id.cameraScopeContainer);
        mCameraScopePager.setOffscreenPageLimit(1);
        mCameraScopePager.setAdapter(mCameraScopeAdapter);

        TabLayout dotsLayout = (TabLayout) findViewById(R.id.dots);
        dotsLayout.setupWithViewPager(mCameraScopePager);

        ImageButton btnZoom = (ImageButton) findViewById(R.id.btnZoom);
        btnZoom.setVisibility(View.INVISIBLE);
    }
    private native int naMain(String[] argv, IMUControl pThis);
    private native void naOnAppStateChange(int state);
    static {
        System.loadLibrary("IMUControl");
    }

}
